python -u main.py \
    --cfg configs/EPIC-D12D2.yaml